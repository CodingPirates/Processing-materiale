# ShooterGameDemo

A simple game in processing javascript, for learning purposes. Shoot with mouse, move with WASD.

Graphics and code can be easily edited. Name images the same as current, and edit code by opening index.html with a text editor.
